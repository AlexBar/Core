﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MvcExtensions.StructureMap.Tests")]
[assembly: AssemblyProduct("MvcExtensions.StructureMap.Tests")]
[assembly: Guid("c85d426d-3d91-4f77-9799-eb542d5cd8df")]