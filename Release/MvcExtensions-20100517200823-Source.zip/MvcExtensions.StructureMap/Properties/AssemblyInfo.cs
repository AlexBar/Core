﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyTitle("MvcExtensions.StructureMap")]
[assembly: AssemblyProduct("MvcExtensions.StructureMap")]
[assembly: CLSCompliant(true)]
[assembly: Guid("a14777a0-d519-49d1-b11d-62979f173d5c")]