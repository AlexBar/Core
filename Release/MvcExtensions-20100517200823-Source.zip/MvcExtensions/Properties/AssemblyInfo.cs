﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyTitle("MvcExtensions (SP1 Preview)")]
[assembly: AssemblyProduct("MvcExtensions (SP1 Preview)")]
[assembly: CLSCompliant(true)]
[assembly: Guid("c16bbd53-b25e-42e5-b75b-f9132846a59c")]
[assembly: NeutralResourcesLanguage("en-US")]