#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Kazi Manzur Rashid")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright � Kazi Manzur Rashid 2009-2010")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]