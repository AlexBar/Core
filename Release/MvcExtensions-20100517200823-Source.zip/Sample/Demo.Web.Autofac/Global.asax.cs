﻿namespace Demo.Web.Autofac
{
    using MvcExtensions.Autofac;

    public class MvcApplication : AutofacMvcApplication
    {
    }
}