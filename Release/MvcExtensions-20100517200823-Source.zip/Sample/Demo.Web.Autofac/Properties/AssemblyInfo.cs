﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.Autofac")]
[assembly: AssemblyProduct("Demo.Web.Autofac")]
[assembly: Guid("4c110af2-679a-4cea-b4bb-58947e7bd76e")]