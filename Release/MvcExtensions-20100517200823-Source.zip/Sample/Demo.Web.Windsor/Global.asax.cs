﻿namespace Demo.Web.Windsor
{
    using MvcExtensions.Windsor;

    public class MvcApplication : WindsorMvcApplication
    {
    }
}