﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.Windsor")]
[assembly: AssemblyProduct("Demo.Web.Windsor")]
[assembly: Guid("d2fad44d-101b-4f7b-91c0-2c3441be8aa3")]