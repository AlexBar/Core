﻿namespace Demo.Web.Ninject
{
    using MvcExtensions.Ninject;

    public class MvcApplication : NinjectMvcApplication
    {
    }
}