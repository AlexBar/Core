﻿namespace Demo.Web.StructureMap
{
    using MvcExtensions.StructureMap;

    public class MvcApplication : StructureMapMvcApplication
    {
    }
}