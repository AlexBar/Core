﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.StructureMap")]
[assembly: AssemblyProduct("Demo.Web.StructureMap")]
[assembly: Guid("3a8ce59f-4242-4c6d-8676-4239459d4d8f")]