﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.Common")]
[assembly: AssemblyProduct("Demo.Web.Common")]
[assembly: Guid("75a28d9f-ba4e-4401-812f-3f43c464cca3")]