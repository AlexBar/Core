﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.Unity")]
[assembly: AssemblyProduct("Demo.Web.Unity")]
[assembly: Guid("2ef1e85a-d0b8-4516-a759-de918a8907a0")]