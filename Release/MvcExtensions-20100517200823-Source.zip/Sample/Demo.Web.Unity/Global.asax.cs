﻿namespace Demo.Web.Unity
{
    using MvcExtensions.Unity;

    public class MvcApplication : UnityMvcApplication
    {
    }
}