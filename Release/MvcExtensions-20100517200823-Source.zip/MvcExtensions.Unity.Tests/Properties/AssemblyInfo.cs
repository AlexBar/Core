﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MvcExtensions.Unity.Tests")]
[assembly: AssemblyProduct("MvcExtensions.Unity.Tests")]
[assembly: Guid("31858014-1671-47b5-bbfc-60cee49261e0")]