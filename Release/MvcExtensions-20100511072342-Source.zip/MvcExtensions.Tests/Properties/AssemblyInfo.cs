﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MvcExtensions.Tests")]
[assembly: AssemblyProduct("MvcExtensions.Tests")]
[assembly: Guid("098012a4-3f04-409f-afe3-4aab6ea39ae9")]