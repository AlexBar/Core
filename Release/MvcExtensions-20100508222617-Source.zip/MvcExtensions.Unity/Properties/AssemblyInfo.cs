﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyTitle("MvcExtensions.Unity")]
[assembly: AssemblyProduct("MvcExtensions.Unity")]
[assembly: CLSCompliant(true)]
[assembly: Guid("8bcb98e3-3223-4ee0-bc3e-4216628821da")]