﻿#region Copyright
// Copyright (c) 2009 - 2010, Kazi Manzur Rashid <kazimanzurrashid@gmail.com>.
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.
#endregion

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MvcExtensions.Ninject.Tests")]
[assembly: AssemblyProduct("MvcExtensions.Ninject.Tests")]
[assembly: Guid("390217eb-cc0f-4366-a82e-bad9431b7386")]