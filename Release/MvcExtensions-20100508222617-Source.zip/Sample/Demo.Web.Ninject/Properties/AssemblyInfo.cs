﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Demo.Web.Ninject")]
[assembly: AssemblyProduct("Demo.Web.Ninject")]
[assembly: Guid("89835762-5f3a-45cf-8446-0fc89296317a")]